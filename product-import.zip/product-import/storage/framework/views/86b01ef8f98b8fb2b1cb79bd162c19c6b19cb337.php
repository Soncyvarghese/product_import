<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
         <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<div class="container col-sm-6">
    <div class="card bg-light mt-3">
    <div class="card-header logout_">
           <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger">Logout</a>
        </div>
        <div class="card-header">
           Import Product
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('import')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="file" name="file" class="form-control" required>
                <br>
                <button class="btn btn-success">Import User Data</button>
                <a href="<?php echo url('samplefile/product.csv'); ?>" class="btn btn-primary">Sample CSV download</a>
            </form>
        </div>
    </div>
   
</div>
<h4>Product List</h4>
<div class="container col-sm-8">
    <table class="table table-bordered data-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Product Name</th>
                    <th>SKU</th>
                    <th>Price</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
    </table>
</div>
<script type="text/javascript">
  $(function () {
    
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('home')); ?>",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'name', name: 'name'},
            {data: 'SKU', name: 'SKU'},
            {data: 'price', name: 'price'},
            {data: 'description', name: 'description'}
        ]
    });
    
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/soncy/product-import/resources/views/home.blade.php ENDPATH**/ ?>