<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
         <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<?php if(session('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<div class="container col-sm-4">
    <div class="card bg-light mt-3">
        <div class="card-header">
        Login
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo e(route('login.post')); ?>">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
                    <div class="form-group form-floating mb-3">
                        <input type="email" class="form-control" name="email"  placeholder="name@example.com" required="required" autofocus>
                        <?php if($errors->has('email')): ?>
                            <span class="text-danger text-left"><?php echo e($errors->first('email')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group form-floating mb-3">
                        <input type="password" class="form-control" name="password"  placeholder="Password" required="required">
                        <?php if($errors->has('password')): ?>
                            <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button class="w-50_ btn btn-lg btn-success" style="float: left;49%!important" type="submit">Login</button>
                    <a class="w-50 btn btn-lg btn-primary"  href="<?php echo e(route('register')); ?>">Register</a>

                </form>
            </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/soncy/product-import/resources/views/login.blade.php ENDPATH**/ ?>