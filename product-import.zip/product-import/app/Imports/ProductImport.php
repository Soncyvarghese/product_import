<?php

namespace App\Imports;

use App\Models\Product;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Auth;

class ProductImport implements ToModel, WithHeadingRow
{
    /**
    * @param Collection $collection
    */
    public function model(array $row)
    { 
        return new Product([
            'user_id'       =>Auth::id(),
            'name'          => $row['name'],
            'price'         => $row['price'], 
            'SKU'           => $row['sku'],
            'description'   => $row['description']
        ]);
    }
}
