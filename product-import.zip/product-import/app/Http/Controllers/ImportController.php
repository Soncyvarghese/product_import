<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Imports\ProductImport;
use Maatwebsite\Excel\Facades\Excel;

class ImportController extends Controller
{

    public function sampleExcel()
    {
          return Excel::download(new HospitalDoctorExcel, 'product.csv');  
    }

    public function import() 
    {
        Excel::import(new ProductImport,request()->file('file'));
             
        return back();
    }
}
