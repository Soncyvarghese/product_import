<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use DataTables;

class AuthController extends Controller
{
    
    public function show()
    {
        return view('register');
    }

   
    public function register(Request $request) 
    {
        $params = $request->validate([
            'name'    => 'required',
            'email'      => 'required|email',
            'password'    => 'required|min:8',
            'password_confirmation' => 'required|same:password'
        ]);
        $registerData=array(
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>Hash::make($request->password),
            'created_at'=>date('Y-m-d H:i:s'),
            'updated_at'=>date('Y-m-d H:i:s')
          );
          $userId=User::saveData($registerData);
        return redirect('/')->with('success', "Account successfully registered.");
    }

    public function login(Request $request) 
    {
        $params = $request->validate([
            'email'      => 'required|email',
            'password'    => 'required|min:8'
           
        ]);
        $credentials = $request->only('email', 'password');
        if (Auth::attempt($credentials)) {
            return redirect()->intended('home')
            ->with('success','You have Successfully loggedin');
        }
        return redirect('/')->with('error','Oops! You have entered invalid credentials');
    }

    public function dashboard(Request $request)
    {
        if(Auth::check()){
            if ($request->ajax()) {
                $data = Product::select('*')->where('user_id',Auth::id());
                return Datatables::of($data)
                        ->addIndexColumn()
                        ->rawColumns(['action'])
                        ->make(true);
            }
            return view('home');
        }
        return redirect("/")->with('error','Opps! You do not have access');
    }

    public function perform()
    {

        Auth::logout();

        return redirect('/')->with('success','Log out successfully');
    }

    
}