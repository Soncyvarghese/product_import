@extends('layouts.master')

@section('content')
@if (session('success'))
    <div class="alert alert-success" role="alert">
         {{ session('success') }}
    </div>
@endif
@if (session('error'))
    <div class="alert alert-danger" role="alert">
        {{ session('error') }}
    </div>
@endif
<div class="container col-sm-4">
    <div class="card bg-light mt-3">
        <div class="card-header">
        Login
        </div>
        <div class="card-body">
            <form method="post" action="{{ route('login.post') }}">
            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                    <div class="form-group form-floating mb-3">
                        <input type="email" class="form-control" name="email"  placeholder="name@example.com" required="required" autofocus>
                        @if ($errors->has('email'))
                            <span class="text-danger text-left">{{ $errors->first('email') }}</span>
                        @endif
                    </div>
                    <div class="form-group form-floating mb-3">
                        <input type="password" class="form-control" name="password"  placeholder="Password" required="required">
                        @if ($errors->has('password'))
                            <span class="text-danger text-left">{{ $errors->first('password') }}</span>
                        @endif
                    </div>
                    <button class="w-50_ btn btn-lg btn-success" style="float: left;49%!important" type="submit">Login</button>
                    <a class="w-50 btn btn-lg btn-primary"  href="{{ route('register') }}">Register</a>

                </form>
            </div>
@endsection