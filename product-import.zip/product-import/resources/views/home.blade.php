@extends('layouts.master')

@section('content')
@if (session('success'))
    <div class="alert alert-success" role="alert">
         {{ session('success') }}
    </div>
@endif
@if (session('error'))
    <div class="alert alert-danger" role="alert">
        {{ session('error') }}
    </div>
@endif
<div class="container col-sm-6">
    <div class="card bg-light mt-3">
    <div class="card-header logout_">
           <a href="{{ route('logout') }}" class="btn btn-danger">Logout</a>
        </div>
        <div class="card-header">
           Import Product
        </div>
        <div class="card-body">
            <form action="{{ route('import') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <input type="file" name="file" class="form-control" required>
                <br>
                <button class="btn btn-success">Import User Data</button>
                <a href="{!! url('samplefile/product.csv') !!}" class="btn btn-primary">Sample CSV download</a>
            </form>
        </div>
    </div>
   
</div>
<h4>Product List</h4>
<div class="container col-sm-8">
    <table class="table table-bordered data-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Product Name</th>
                    <th>SKU</th>
                    <th>Price</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
    </table>
</div>
<script type="text/javascript">
  $(function () {
    
    var table = $('.data-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('home') }}",
        columns: [
            {data: 'id', name: 'id'},
            {data: 'name', name: 'name'},
            {data: 'SKU', name: 'SKU'},
            {data: 'price', name: 'price'},
            {data: 'description', name: 'description'}
        ]
    });
    
  });
</script>
@endsection
